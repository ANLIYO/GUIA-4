Las im�genes de los aspirantes fueron tomadas de http://office.microsoft.com/en-us/clipart/
Las im�gen del t�tulo fue tomada de la galer�a de Microsoft Office